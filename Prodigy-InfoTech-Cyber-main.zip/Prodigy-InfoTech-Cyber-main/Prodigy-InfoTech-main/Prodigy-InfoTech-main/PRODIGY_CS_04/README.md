#Task 4
<b>Simple Keylogger</b>

This Python program implements a basic keylogger that records and logs keystrokes. It captures the keys pressed by the user and saves them to a log file, providing an educational tool for understanding how keylogging works. This program includes ethical considerations and requires user consent before running.

<b>Features</b>

- <b>Key Logging:</b> Records and logs every keystroke along with a timestamp.
- <b>Log File:</b> Saves the logged keystrokes to a specified file.
- <b>User Consent:</b> Includes a disclaimer and requires user acceptance of terms and conditions.
- <b>Duration Control:</b> Allows the user to specify the duration for which the keystrokes should be logged.

<b>Usage</b>

1. <b>Run the Program:</b> Execute the script to start the keylogger program.
2. <b>Read and Accept Disclaimer:</b> Carefully read the disclaimer and accept the terms and conditions to proceed.
3. <b>Specify Duration:</b> Enter the duration in seconds for which the keylogger should run.
4. <b>Logging Keystrokes:</b> The program will capture and log keystrokes during the specified period.
5. <b>Review Log:</b> After the duration ends, the log file containing the keystrokes will be saved and its location displayed.

This code was developed as part of my internship at The Prodigy Infotech, demonstrating the creation of a basic keylogger for educational purposes while emphasizing ethical usage and user consent.
