# Prodigy-InfoTech-Cyber
Caesar-Cipher.py is a Python tool that encrypts and decrypts text using the classic Caesar cipher, where each letter in a message is shifted by a fixed number of positions in the alphabet, wrapping around when needed, while typically leaving spaces, punctuation, and numbers unchanged.
